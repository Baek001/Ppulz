import styles from './Trust.module.css';

export default function Trust() {
    return (
        <section className={styles.section}>
            <div className={`container ${styles.container}`}>
                <h2 className={styles.sectionTitle}>
                    PPulse는 신뢰할 수 있는<br />
                    <span className={styles.highlight}>데이터 분석 도구</span>입니다
                </h2>

                <div className={styles.content}>
                    <p className={styles.desc}>
                        PPulse가 제공하는 '분위기 점수'는 뉴스 기사와 법안 발의 데이터를<br />
                        자연어 처리(NLP) 기술로 분석하여 정량화한 지표입니다.
                    </p>

                    <div className={styles.disclaimerBox}>
                        <strong className={styles.disclaimerTitle}>면책 조항</strong>
                        <p className={styles.disclaimerText}>
                            본 서비스가 제공하는 모든 정보는 투자 판단의 참고 자료일 뿐이며, 투자의 최종 책임은 사용자 본인에게 있습니다.<br />
                            PPulse는 어떠한 경우에도 투자 결과에 대한 법적 책임을 지지 않습니다.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    );
}
