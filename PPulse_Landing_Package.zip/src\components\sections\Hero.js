import styles from './Hero.module.css';
import Button from '../ui/Button';
import DemoGraph from './DemoGraph';

export default function Hero() {
    return (
        <section className={styles.hero}>
            <div className={`container ${styles.container}`}>
                <div className={styles.content}>
                    <h1 className={styles.title}>
                        지금 세상의 분위기,<br />
                        <span className={styles.highlight}>숫자 하나</span>로 읽으세요
                    </h1>
                    <p className={styles.description}>
                        복잡한 뉴스, 읽기 힘든 법안 대신<br />
                        PPulse가 분석한 명쾌한 점수와 한 줄 코멘트로 충분합니다.
                    </p>
                    <div className={styles.actions}>
                        <Button size="lg">시작하기</Button>
                        <Button size="lg" variant="outline">데모 보기</Button>
                    </div>
                </div>
                <div className={styles.visual}>
                    <DemoGraph />
                </div>
            </div>
        </section>
    );
}
