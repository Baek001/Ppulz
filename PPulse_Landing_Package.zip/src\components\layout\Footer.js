import styles from './Footer.module.css';

export default function Footer() {
    return (
        <footer className={styles.footer}>
            <div className={`container ${styles.container}`}>
                <div className={styles.top}>
                    <div className={styles.brand}>
                        <div className={styles.logo}>PPulse</div>
                        <p className={styles.desc}>
                            뉴스/법안 데이터를 분석해<br />
                            지금의 분위기를 점수로 보여주는 서비스
                        </p>
                    </div>
                    <div className={styles.links}>
                        <div className={styles.column}>
                            <h4>서비스</h4>
                            <a href="#">기능 소개</a>
                            <a href="#">사용 방법</a>
                            <a href="#">요금제</a>
                        </div>
                        <div className={styles.column}>
                            <h4>지원</h4>
                            <a href="#">자주 묻는 질문</a>
                            <a href="#">문의하기</a>
                        </div>
                    </div>
                </div>
                <div className={styles.bottom}>
                    <p>© 2024 PPulse. All rights reserved.</p>
                    <div className={styles.legal}>
                        <a href="#">이용약관</a>
                        <a href="#">개인정보처리방침</a>
                    </div>
                </div>
            </div>
        </footer>
    );
}
