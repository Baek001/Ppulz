import "./globals.css";

export const metadata = {
  title: "PPulse - 분위기를 읽다",
  description: "뉴스/법안 데이터를 분석해 지금의 분위기를 점수로 보여주는 서비스",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ko">
      <body>
        {children}
      </body>
    </html>
  );
}
