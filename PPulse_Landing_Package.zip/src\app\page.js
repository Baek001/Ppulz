import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import Hero from '@/components/sections/Hero';
import HowToUse from '@/components/sections/HowToUse';
import Features from '@/components/sections/Features';
import Trust from '@/components/sections/Trust';

export default function Home() {
  return (
    <main>
      <Header />
      <Hero />
      <HowToUse />
      <Features />
      <Trust />
      <Footer />
    </main>
  );
}
