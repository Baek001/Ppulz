import styles from './Header.module.css';
import Button from '../ui/Button';

export default function Header() {
    return (
        <header className={styles.header}>
            <div className={`container ${styles.container}`}>
                <div className={styles.logo}>
                    PPulse
                </div>

                <nav className={styles.nav}>
                    <a href="#features">기능</a>
                    <a href="#how-it-works">사용방법</a>
                    <a href="#pricing">요금제</a>
                    <a href="#faq">FAQ</a>
                </nav>

                <div className={styles.actions}>
                    <Button variant="ghost" size="sm">로그인</Button>
                    <Button variant="primary" size="sm">시작하기</Button>
                </div>
            </div>
        </header>
    );
}
