import styles from './Features.module.css';

const FEATURES = [
    {
        title: "피로도 없는 뉴스 소비",
        desc: "자극적인 헤드라인에 지치셨나요?\n핵심만 담은 점수로 세상의 흐름을 읽으세요."
    },
    {
        title: "한국/미국 신호 통합",
        desc: "국내 이슈부터 글로벌 트렌드까지,\nPPulse 하나로 모두 파악할 수 있습니다."
    },
    {
        title: "매시간 업데이트",
        desc: "변화하는 여론과 법안의 움직임을\n실시간에 가깝게 포착합니다."
    },
    {
        title: "근거는 필요할 때만",
        desc: "원평문과 출처는 클릭 한 번으로,\n평소엔 직관적인 요약만 보세요."
    }
];

export default function Features() {
    return (
        <section id="features" className={styles.section}>
            <div className={`container ${styles.container}`}>
                <h2 className={styles.sectionTitle}>
                    왜 <span className={styles.logo}>PPulse</span>여야 할까요?
                </h2>

                <div className={styles.grid}>
                    {FEATURES.map((item, idx) => (
                        <div key={idx} className={styles.card}>
                            <h3 className={styles.cardTitle}>{item.title}</h3>
                            <p className={styles.cardDesc}>{item.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
